@echo off
:: check for admin rights
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

reg delete "HKCR\*\shell\WinCipher" /f >nul 2>&1

set "TARGET_DIR=C:\Program Files\WinCipher"
set "SELF=%~f0"

cmd /c ping 127.0.0.1 -n 3 >nul & ^
rmdir /s /q "%TARGET_DIR%" & ^
del "%SELF%" >nul 2>&1

exit