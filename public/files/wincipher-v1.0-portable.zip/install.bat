@echo off
:: check for admin rights
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "TARGET_DIR=C:\Program Files\WinCipher"
set "SOURCE_DIR=%~dp0"

if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%" >nul 2>&1
)

xcopy "%SOURCE_DIR%*" "%TARGET_DIR%\" /E /I /Y >nul 2>&1

reg add "HKCR\*\shell\WinCipher" /ve /d "Encrypt/Decrypt" /f
reg add "HKCR\*\shell\WinCipher\command" /ve /d "\"%TARGET_DIR%\bin\wincipher.exe\" \"%%1"" /f

echo WinCipher installed
pause